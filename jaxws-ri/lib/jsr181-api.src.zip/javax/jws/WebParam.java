/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2004-2010 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.jws;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

/**
 * Customizes the mapping of an individual parameter to a Web Service message part and XML element.
 */
@Retention(value = RetentionPolicy.RUNTIME)
@Target(value = {ElementType.PARAMETER})
public @interface WebParam {

    /**
     * The direction in which the parameter flows
     */
    public enum Mode {
        IN,
        OUT,
        INOUT
    };

    /**
     * Name of the parameter.
     * <p>
     * If the operation is rpc style and @WebParam.partName has not been specified, this is name of the wsdl:part
     * representing the parameter.
     * <br>
     * If the operation is document style or the parameter maps to a header, this is the local name of the XML element
     * representing the parameter.
     * <p>
     * A name MUST be specified if the operation is document style, the parameter style is BARE, and the mode is OUT
     * or INOUT.
     *
     * @specdefault
     *   If the operation is document style and the parameter style is BARE, {@code @WebMethod.operationName}.<br>
     *   Otherwise, argN, where N represents the index of the parameter in the method signature (starting at arg0).
     */
    String name() default "";

    /**
     * The name of the wsdl:part representing this parameter.
     * <p>
     * This is only used if the operation is rpc style or if the operation is document style and the parameter style
     * is BARE.
     *
     * @specdefault {@code @WebParam.name}
     *
     * @since 2.0
     */
    String partName() default "";

    /**
     * The XML namespace for the parameter.
     * <p>
     * Only used if the operation is document style or the paramater maps to a header.
     * If the target namespace is set to "", this represents the empty namespace.
     *
     * @specdefault
     *   If the operation is document style, the parameter style is WRAPPED, and the parameter does not map to a
     *   header, the empty namespace.<br>
     *   Otherwise, the targetNamespace for the Web Service.
     */
    String targetNamespace() default "";

    /**
     * The direction in which the parameter is flowing (One of IN, OUT, or INOUT).
     * <p>
     * The OUT and INOUT modes may only be specified for parameter types that conform to the definition of Holder types
     * (JAX-WS 2.0 [5], section 2.3.3).  Parameters that are Holder Types MUST be OUT or INOUT.
     *
     * @specdefault
     *   INOUT if a Holder type.<br>
     *   IN if not a Holder type.
     */
    Mode mode() default Mode.IN;

    /**
     * If true, the parameter is pulled from a message header rather then the message body.
     */
    boolean header() default false;
};
