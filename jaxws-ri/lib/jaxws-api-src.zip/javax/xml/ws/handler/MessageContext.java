/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2005-2011 Oracle and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://glassfish.dev.java.net/public/CDDL+GPL_1_1.html
 * or packager/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at packager/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * Oracle designates this particular file as subject to the "Classpath"
 * exception as provided by Oracle in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package javax.xml.ws.handler;
import java.util.Map;

/**
 * The interface <code>MessageContext</code> abstracts the message
 * context that is processed by a handler in the <code>handle</code>
 * method.
 *
 * <p>The <code>MessageContext</code> interface provides methods to
 * manage a property set. <code>MessageContext</code> properties
 * enable handlers in a handler chain to share processing related
 * state.
 *
 * @since JAX-WS 2.0
 */
public interface MessageContext extends Map<String, Object> {
    
    /**
     * Standard property: message direction, <code>true</code> for
     * outbound messages, <code>false</code> for inbound.
     * <p>Type: boolean
     */
    public static final String MESSAGE_OUTBOUND_PROPERTY =
            "javax.xml.ws.handler.message.outbound";
    
    /**
     * Standard property: Map of attachments to a message for the inbound
     * message, key is  the MIME Content-ID, value is a DataHandler.
     * <p>Type: java.util.Map&lt;String,DataHandler>
     */
    public static final String INBOUND_MESSAGE_ATTACHMENTS =
            "javax.xml.ws.binding.attachments.inbound";
    
    /**
     * Standard property: Map of attachments to a message for the outbound
     * message, key is the MIME Content-ID, value is a DataHandler.
     * <p>Type: java.util.Map&lt;String,DataHandler>
     */
    public static final String OUTBOUND_MESSAGE_ATTACHMENTS =
            "javax.xml.ws.binding.attachments.outbound";
    
    /**
     * Standard property: input source for WSDL document.
     * <p>Type: org.xml.sax.InputSource
     */
    public static final String WSDL_DESCRIPTION =
            "javax.xml.ws.wsdl.description";
    
    /**
     * Standard property: name of WSDL service.
     * <p>Type: javax.xml.namespace.QName
     */
    public static final String WSDL_SERVICE =
            "javax.xml.ws.wsdl.service";
    
    /**
     * Standard property: name of WSDL port.
     * <p>Type: javax.xml.namespace.QName
     */
    public static final String WSDL_PORT =
            "javax.xml.ws.wsdl.port";
    
    /**
     * Standard property: name of wsdl interface (2.0) or port type (1.1).
     * <p>Type: javax.xml.namespace.QName
     */
    public static final String WSDL_INTERFACE =
            "javax.xml.ws.wsdl.interface";
    
    /**
     * Standard property: name of WSDL operation.
     * <p>Type: javax.xml.namespace.QName
     */
    public static final String WSDL_OPERATION =
            "javax.xml.ws.wsdl.operation";
    
    /**
     * Standard property: HTTP response status code.
     * <p>Type: java.lang.Integer
     */
    public static final String HTTP_RESPONSE_CODE =
            "javax.xml.ws.http.response.code";
    
    /**
     * Standard property: HTTP request headers.
     * <p>Type: java.util.Map&lt;java.lang.String, java.util.List&lt;java.lang.String>>
     */
    public static final String HTTP_REQUEST_HEADERS =
            "javax.xml.ws.http.request.headers";
    
    /**
     * Standard property: HTTP response headers.
     * <p>Type: java.util.Map&lt;java.lang.String, java.util.List&lt;java.lang.String>>
     */
    public static final String HTTP_RESPONSE_HEADERS =
            "javax.xml.ws.http.response.headers";
    
    /**
     * Standard property: HTTP request method.
     * <p>Type: java.lang.String
     */
    public static final String HTTP_REQUEST_METHOD =
            "javax.xml.ws.http.request.method";
    
    /**
     * Standard property: servlet request object.
     * <p>Type: javax.servlet.http.HttpServletRequest
     */
    public static final String SERVLET_REQUEST =
            "javax.xml.ws.servlet.request";
    
    /**
     * Standard property: servlet response object.
     * <p>Type: javax.servlet.http.HttpServletResponse
     */
    public static final String SERVLET_RESPONSE =
            "javax.xml.ws.servlet.response";
    
    /**
     * Standard property: servlet context object.
     * <p>Type: javax.servlet.ServletContext
     */
    public static final String SERVLET_CONTEXT =
            "javax.xml.ws.servlet.context";
    
    /**
     * Standard property: Query string for request.
     * <p>Type: String
     **/
    public static final String QUERY_STRING =
            "javax.xml.ws.http.request.querystring";
    
    /**
     * Standard property: Request Path Info
     * <p>Type: String
     */
    public static final String PATH_INFO =
            "javax.xml.ws.http.request.pathinfo";
    
    /**
     * Standard property: WS Addressing Reference Parameters.
     * The list MUST include all SOAP headers marked with the
     * wsa:IsReferenceParameter="true" attribute.
     * <p>Type: List&lt;Element>
     *
     * @since JAX-WS 2.1
     */
    public static final String REFERENCE_PARAMETERS =
            "javax.xml.ws.reference.parameters";
    
    /**
     * Property scope. Properties scoped as <code>APPLICATION</code> are
     * visible to handlers,
     * client applications and service endpoints; properties scoped as
     * <code>HANDLER</code>
     * are only normally visible to handlers.
     */
    public enum Scope {APPLICATION, HANDLER};
    
    /** 
     * Sets the scope of a property.
     *
     * @param name Name of the property associated with the
     *             <code>MessageContext</code>
     * @param scope Desired scope of the property
     * @throws java.lang.IllegalArgumentException if an illegal
     *             property name is specified
     */
    public void setScope(String name,  Scope scope);
    
    /** 
     * Gets the scope of a property.
     *
     * @param name Name of the property
     * @return Scope of the property
     * @throws java.lang.IllegalArgumentException if a non-existant
     *             property name is specified
     */
    public Scope getScope(String  name);
}
